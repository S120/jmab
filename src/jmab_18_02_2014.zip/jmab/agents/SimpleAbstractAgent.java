/*
 * JMAB - Java Macroeconomic Agent Based Modeling Toolkit
 * Copyright (C) 2013 Alessandro Caiani and Antoine Godin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 3 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 */
package jmab.agents;

import java.util.ArrayList;

import jmab.events.DeadAgentEvent;
import jmab.simulations.CreditMarketSimulation;
import jmab.simulations.GoodMarketSimulation;
import jmab.simulations.MacroSimulation;
import jmab.strategies.BorrowingStrategy;
import jmab.strategies.BuyingStrategy;
import jmab.strategies.MacroStrategy;
import jmab.strategies.PricingStrategy;
import jmab.strategies.ProductionStrategy;
import net.sourceforge.jabm.EventScheduler;
import net.sourceforge.jabm.agent.AbstractAgent;
import net.sourceforge.jabm.agent.Agent;
import net.sourceforge.jabm.event.AgentArrivalEvent;
import net.sourceforge.jabm.event.EventListener;
import net.sourceforge.jabm.event.RoundFinishedEvent;
import net.sourceforge.jabm.event.SimEvent;
import net.sourceforge.jabm.strategy.Strategy;

/**
 * @author Alessandro Caiani and Antoine Godin
 *
 */
@SuppressWarnings("serial")
public abstract class SimpleAbstractAgent extends AbstractAgent implements
		MacroAgent, EventListener {

	protected double asset;
	protected double liability;
	protected double realCapital;
	protected boolean[] ActiveAgent;
	protected boolean isDead=false;
	protected int populationId;
	
	
	public SimpleAbstractAgent(){
		this.asset=0;
		this.liability=0;
		this.realCapital=0;
		this.ActiveAgent=null;
		this.populationId=0;
	};
	/**
	 * @param numberMarkets
	 */
	public SimpleAbstractAgent(int numberMarketsAttended, int populationId) {
		super();
		this.ActiveAgent = new boolean [numberMarketsAttended];
		this.populationId=populationId;
	}

	/**
	 * @param scheduler
	 */
	public SimpleAbstractAgent(EventScheduler scheduler, int numberMarketsAttended, int populationId) {
		super(scheduler);
		this.ActiveAgent = new boolean [numberMarketsAttended];
		this.populationId=populationId;
	}
	
	/**
	 * @return the populationId
	 */
	public int getPopulationId() {
		return populationId;
	}

	/**
	 * @param populationId the populationId to set
	 */
	public void setPopulationId(int populationId) {
		this.populationId = populationId;
	}
	
	/**
	 * @return the populationId
	 */
	public int getNumberMarketsAttended() {
		return this.ActiveAgent.length;
	}

	/**
	 * @param populationId the populationId to set
	 */
	public void setNumberMarkets(int numberMarkets) {
		this.ActiveAgent = new boolean[numberMarkets];
	}

	/**
	 * @param populationId the populationId to set
	 */
	public int getNumberMarkets() {
		return ActiveAgent.length;
	}
	
	/**
	 * @param realCapital the realCapital to set
	 */
	public void setRealCapital(double realCapital) {
		this.realCapital = realCapital;
	}

	/* (non-Javadoc)
	 * @see net.sourceforge.jabm.agent.Agent#getPayoff()
	 */
	@Override
	abstract public double getPayoff();
	/* (non-Javadoc)
	 * @see net.sourceforge.jabm.agent.Agent#initialise()
	 */
	@Override
	public void initialise() {
		activateAgent();
	}
	
	public void activateAgent(){
		for(int i=0;i<ActiveAgent.length;i++){
			ActiveAgent[i]=true;
		}
	}
	
	protected void buyGood(ArrayList<Agent> arrayListAgent,GoodMarketSimulation simulation, double demand, 
			int strategyID, int marketID, boolean real) {
		MacroStrategy strategies = (MacroStrategy) getStrategy();
		BuyingStrategy buyingStrategy = (BuyingStrategy) strategies.getStrategy(strategyID);
		Agent seller=buyingStrategy.selectSeller(arrayListAgent, demand, real);
		simulation.commitTransaction(this, seller,marketID);
	}

	protected void getLoan(ArrayList<Agent> lenders,CreditMarketSimulation simulation, double amount, int length, 
			int strategyID, int creditID) {
		MacroStrategy strategies = (MacroStrategy) getStrategy();
		BorrowingStrategy borrowingStrategy = (BorrowingStrategy) strategies.getStrategy(strategyID);
		Agent lender=borrowingStrategy.selectLender(lenders, amount, length);
		simulation.commitCredit(this, lender, creditID);
	}
	
	protected double getPrice(Buyer buyer, double demand, boolean real, int strategyID){
		if(isDead)
			return Double.POSITIVE_INFINITY;
		else{
			MacroStrategy strategies = (MacroStrategy) getStrategy();
			PricingStrategy buyingStrategy = (PricingStrategy) strategies.getStrategy(strategyID);
			return buyingStrategy.setPrice((Seller)this, buyer, demand, real);
		}
	}
	
	protected double getOutput(int strategyID){
		MacroStrategy strategies = (MacroStrategy) getStrategy();
		ProductionStrategy productionStrategy = (ProductionStrategy) strategies.getStrategy(strategyID);
		return productionStrategy.setOutput(this);
	}

	protected Strategy getStrategy(int strategyID){
		MacroStrategy strategies = (MacroStrategy) getStrategy();
		return strategies.getStrategy(strategyID);
	}
	
	@Override
	public void eventOccurred(SimEvent event) {
		if (event instanceof RoundFinishedEvent) {
			onRoundFinished((RoundFinishedEvent)event);
		} else {
			super.eventOccurred(event);
		}
	}
	
	public void onRoundFinished(RoundFinishedEvent event){
		if(isDead){
			MacroSimulation simulation = (MacroSimulation)event.getSimulation();
			simulation.agentDie(populationId, this);
		}else{
			activateAgent();
		}
	}
	
	protected void dies(){
		this.isDead=true;
		super.fireEvent(new DeadAgentEvent(this));
	}
	
	public void onAgentArrival(AgentArrivalEvent event) {
	}
	
	public double getBalance(){
		return asset-liability;
	}
	
	public double getAsset(){
		return asset;
	}
	
	public void setAsset(double amount){
		this.asset=amount;
	}
	
	protected void deposit(double amount){
		asset+=amount;
	}
	
	protected void withdraw(double amount){
		asset-=amount;
	}
	
	public double getLiability(){
		return liability;
	}
	
	public void setLiability(double amount){
		this.liability=amount;
	}
		
	protected void addDebt(double amount){
		liability+=amount;
	}
	
	protected void removeDebt(double amount){
		liability-=amount;
	}
	
	public double getRealCapital(){
		return realCapital;
	}
	
	protected void addRealCapital(double quantity){
		realCapital+=quantity;
	}
	
	protected void removeRealCapital(double quantity){
		realCapital-=quantity;
	}
	
	public boolean isActive (int idMarket){
		return ActiveAgent[idMarket];
	}
	
	public void setActive (boolean active, int idMarket ){
		this.ActiveAgent[idMarket]= active;
	}
	
	public int getMarketsAttended(){
		return ActiveAgent.length;
	}
	/* (non-Javadoc)
	 * @see net.sourceforge.jabm.agent.AbstractAgent#subscribeToEvents()
	 */
	@Override
	public void subscribeToEvents() {
		//set the agent as a listerner of AgentArrival, SimulationFinished
		//and RoundStartingEvent by calling the super.subscribetoevents method
		super.subscribeToEvents(); 
		//in jmab agents also listen to RoundFinishedEvent (to update stocks), 
		//hence we have to set them as listener of this event
		scheduler.addListener(RoundFinishedEvent.class, this);
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#clone()
	 */
	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
}

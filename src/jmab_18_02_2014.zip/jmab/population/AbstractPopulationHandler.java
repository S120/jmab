/*
 * JMAB - Java Macroeconomic Agent Based Modeling Toolkit
 * Copyright (C) 2013 Alessandro Caiani and Antoine Godin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 3 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 */
package jmab.population;

import java.util.List;

import jmab.init.MacroAgentInitialiser;
import net.sourceforge.jabm.agent.Agent;
import net.sourceforge.jabm.agent.AgentList;

/**
 * @author Alessandro Caiani and Antoine Godin
 *
 */
public abstract class AbstractPopulationHandler implements PopulationHandler{
	
	MacroAgentInitialiser initialiser;
	
	/**
	 * 
	 */
	public AbstractPopulationHandler() {
	}
	
	public void agentDie(int populationId, Agent agent,MacroPopulation populations){
		AgentList agentList = populations.getPopulation(populationId).getAgentList();
		List<Agent> agents = agentList.getAgents();
		int id = agents.indexOf(agent);
		if(id>=0){//TODO
			handleAgent(agent, id, agents, populationId);
		}
	}
	
	/**
	 * @return the initialiser
	 */
	public MacroAgentInitialiser getInitialiser() {
		return initialiser;
	}

	/**
	 * @param initialiser the initialiser to set
	 */
	public void setInitialiser(MacroAgentInitialiser initialiser) {
		this.initialiser = initialiser;
	}

	/**
	 * @param agent
	 * @param id
	 * @param agents
	 */
	abstract protected void handleAgent(Agent agent, int id, List<Agent> agents, int populationId);
}

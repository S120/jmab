/*
 * JMAB - Java Macroeconomic Agent Based Modeling Toolkit
 * Copyright (C) 2013 Alessandro Caiani and Antoine Godin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 3 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 */
package jmab.population;

import java.util.ArrayList;
import java.util.Collection;

import net.sourceforge.jabm.Population;
import net.sourceforge.jabm.agent.Agent;
import net.sourceforge.jabm.agent.AgentList;
import net.sourceforge.jabm.event.EventListener;
import net.sourceforge.jabm.event.SimEvent;
import cern.jet.random.engine.RandomEngine;

/**
 * @author Alessandro Caiani and Antoine Godin
 *
 */
//A MacroPopulation is an object containing a list of populations

@SuppressWarnings("serial")
public class MacroPopulation extends Population implements EventListener{
	
	protected ArrayList<Population> populations;

	/**
	 * 
	 */
	public MacroPopulation() {
		super();
	}

	/**
	 * @param populations
	 */
	
	public MacroPopulation(ArrayList<Population> populations) {
	}
	
	
	
	//get single Population based on its ID (position in list of lists)
	public Population getPopulation(int populationId){
		return populations.get(populationId);
	}
	
	/**
	 * @return the populations
	 */
	//return all populations
	public ArrayList<Population> getPopulations() {
		return populations;
	}

	/**
	 * @param populations the populations to set
	 */
	
	public void setPopulations(ArrayList<Population> populations) {
		this.populations = populations;
	}
	
	public void reset(){
		for(Population pop:populations){
			pop.reset();
		}
	}
	
	//set an AgentList composed of the agents belonging to a specific population
	public void setAgentList(AgentList agentList, int populationId) {
		Population pop=populations.get(populationId);
		pop.setAgentList(agentList);
	}
	
	//add an agent to a specific population
	public void add(Agent agent, int populationId) {
		Population pop=populations.get(populationId);
		pop.add(agent);
	}
	
	public void setPrng(RandomEngine prng) {
		for(Population pop:populations){
			pop.setPrng(prng);
		}
	}
	
	@Override
	public void eventOccurred(SimEvent event) {
	}



	/* (non-Javadoc)
	 * @see net.sourceforge.jabm.Population#getAgents()
	 */
	@Override
	public Collection<Agent> getAgents() {
		ArrayList<Agent> completeListOfAgents = new ArrayList<Agent>();
		for (Population pop: populations) {
			completeListOfAgents.addAll(pop.getAgents());	
		}
		return completeListOfAgents;
		
	}
	
}

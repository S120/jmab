/*
 * JMAB - Java Macroeconomic Agent Based Modeling Toolkit
 * Copyright (C) 2013 Alessandro Caiani and Antoine Godin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 3 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 */
package jmab.simulations;

import java.util.ArrayList;

import jmab.population.MacroPopulation;
import jmab.population.PopulationHandler;
import net.sourceforge.jabm.AbstractSimulation;
import net.sourceforge.jabm.SimulationTime;
import net.sourceforge.jabm.agent.Agent;
import net.sourceforge.jabm.event.RoundFinishedEvent;
import net.sourceforge.jabm.event.RoundStartingEvent;
import net.sourceforge.jabm.event.SimulationFinishedEvent;
import net.sourceforge.jabm.event.SimulationStartingEvent;

/**
 * @author Alessandro Caiani and Antoine Godin
 *
 */
@SuppressWarnings("serial")
public abstract class AbstractMacroSimulation extends AbstractSimulation implements
		MacroSimulation {
	
	protected ArrayList<MarketSimulation> markets;
	protected int activeMarketId;
	protected MarketSimulation activeMarket;
	protected PopulationHandler handler;
	
	/**
	 * The current round a.k.a. period.
	 */
	protected int round = 0;
	
	/**
	 * The maximum number of rounds.
	 */
	protected int maximumRounds = Integer.MAX_VALUE;
	
	/**
	 * 
	 */
	public AbstractMacroSimulation() {
		super();
	}
	
	

	/**
	 * @return the handler
	 */
	public PopulationHandler getHandler() {
		return handler;
	}

	/**
	 * @param handler the handler to set
	 */
	public void setHandler(PopulationHandler handler) {
		this.handler = handler;
	}

	/**
	 * @return the round
	 */
	public int getRound() {
		return round;
	}


	/* (non-Javadoc)
	 * @see net.sourceforge.jabm.Simulation#getSimulationTime()
	 */
	@Override
	public SimulationTime getSimulationTime() {
		return simulationController.getSimulationTime();
	}

	/* (non-Javadoc)
	 * @see jmab.simulations.MacroSimulation#getActivatedMarketID()
	 */
	@Override
	public int getActiveMarketId() {
		return activeMarketId;
	}

	/* (non-Javadoc)
	 * @see jmab.simulations.MacroSimulation#setActivatedMarketID(int)
	 */
	@Override
	public void setActiveMarketId(int activatedMarketId) {
		this.activeMarketId=activatedMarketId;

	}

	/* (non-Javadoc)
	 * @see jmab.simulations.MacroSimulation#getActiveMarket()
	 */
	@Override
	public MarketSimulation getActiveMarket() {
		return activeMarket;
	}
	
	/**
	 * @param activeMarket the activeMarket to set
	 */
	public void setActiveMarket(MarketSimulation activeMarket) {
		this.activeMarket = activeMarket;
	}
	
	/**
	 * @return the markets
	 */
	public ArrayList<MarketSimulation> getMarkets() {
		return markets;
	}

	/**
	 * @param markets the markets to set
	 */
	public void setMarkets(ArrayList<MarketSimulation> markets) {
		this.markets = markets;
	}
	
	public void agentDie(int populationId, Agent agent){
		handler.agentDie(populationId, agent, (MacroPopulation)this.population);
	}
	
	protected void begin() {
		setListeners();
		initialiseAgents();
		fireEvent(new SimulationStartingEvent(this));
	}
	
	@Override
	public void initialiseAgents() {
		for(MarketSimulation sim:markets){
			sim.initialiseAgents();
		}
	}
	
	/**
	 * 
	 */
	private void setListeners() {
		for(MarketSimulation sim:markets){
			sim.setSimulation(this);
			sim.subscribeToEvents(this.simulationController);
		}
		
	}

	protected void end() {
		fireEvent(new SimulationFinishedEvent(this));
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		begin();
		for(round = 0; round < maximumRounds && isRunning; round++) {
			step();
		}
		end();
	}
	
	@Override
	public void step(){
		super.step();
		fireEvent(new RoundStartingEvent(this));
		invokeMarketSimulations();
		fireEvent(new RoundFinishedEvent(this));
	}

	protected abstract void invokeMarketSimulations();
	
	public int getMaximumRounds() {
		return maximumRounds;
	}

	/**
	 * Configure the maximum number of rounds this simulation will run before
	 * being automatically terminated.
	 * 
	 * @param maximumRounds
	 */
	public void setMaximumRounds(int maximumRounds) {
		this.maximumRounds = maximumRounds;
	}

}

/*
 * JMAB - Java Macroeconomic Agent Based Modeling Toolkit
 * Copyright (C) 2013 Alessandro Caiani and Antoine Godin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 3 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 */
package jmab.simulations;

import jmab.mechanisms.Mechanism;
import jmab.population.MacroPopulation;
import net.sourceforge.jabm.SimulationController;
import net.sourceforge.jabm.agent.Agent;

/**
 * @author Alessandro Caiani and Antoine Godin
 *
 */
@SuppressWarnings("serial")
public class CreditMarket extends AbstractMarketSimulation implements
		CreditMarketSimulation {

	/**
	 * @param simulationController
	 * @param simulation
	 * @param population
	 * @param sellersId
	 * @param buyersId
	 */
	public CreditMarket (){}
	
	public CreditMarket(SimulationController simulationController,
			MacroSimulation simulation, MacroPopulation population,
			int sellersId, int buyersId, Mechanism transaction) {
		super(simulationController, simulation, population, sellersId, buyersId, transaction);
	}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		begin();
		step();
		end();
	}
	
	@Override
	public void step() {
		super.step();
		invokeAgentInteractions();
	}
	
	/**
	 * 
	 */
	private void end() {
		// TODO Auto-generated method stub
	}

	/**
	 * 
	 */
	private void begin() {
		// TODO Auto-generated method stub
	}

	/* (non-Javadoc)
	 * @see jmab.simulations.CreditMarketSimulation#commitCredit(net.sourceforge.jabm.agent.Agent, net.sourceforge.jabm.agent.Agent, int)
	 */
	@Override
	public void commitCredit(Agent debtor, Agent creditor, int idCredit) {
		super.commit(debtor, creditor, idCredit);
	}

}

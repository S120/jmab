/*
 * JMAB - Java Macroeconomic Agent Based Modeling Toolkit
 * Copyright (C) 2013 Alessandro Caiani and Antoine Godin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 3 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 */
package jmab.simulations;

import jmab.events.MarketInteractionsFinishedEvent;
import jmab.events.MarketInteractionsStartingEvent;

/**
 * @author Alessandro Caiani and Antoine Godin
 *
 */
@SuppressWarnings("serial")
public class OrderedMarketsSimulation extends AbstractMacroSimulation implements
		MacroSimulation {
	
	/**
	 * 
	 */
	public OrderedMarketsSimulation() {}

	

	// for each market:set that market as active, set the ActiveMarketID equal to the ID of that
		//market, if the market is not closed: run (the run is contained in GoodMarket and CreditMarket classes)
	/* (non-Javadoc)
	 * @see jmab.simulations.AbstractMacroSimulation#invokeMarketSimulations()
	 */
	@Override
	protected void invokeMarketSimulations() {
		super.fireEvent(new MarketInteractionsStartingEvent(this));
		for(MarketSimulation market:markets){
			setActiveMarket(market);
			setActiveMarketId(market.getMarketId());
			while(!market.closed()){
				market.run();
			}
		}
		super.fireEvent(new MarketInteractionsFinishedEvent(this));
	}


}

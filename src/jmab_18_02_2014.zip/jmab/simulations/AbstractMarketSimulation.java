/*
 * JMAB - Java Macroeconomic Agent Based Modeling Toolkit
 * Copyright (C) 2013 Alessandro Caiani and Antoine Godin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 3 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 */
package jmab.simulations;

import jmab.mechanisms.Mechanism;
import jmab.mixing.MarketMixer;
import jmab.population.MacroPopulation;
import jmab.population.MarketPopulation;
import net.sourceforge.jabm.AbstractSimulation;
import net.sourceforge.jabm.EventScheduler;
import net.sourceforge.jabm.Population;
import net.sourceforge.jabm.SimulationController;
import net.sourceforge.jabm.SimulationTime;
import net.sourceforge.jabm.agent.Agent;

/**
 * @author Alessandro Caiani and Antoine Godin
 *
 */
@SuppressWarnings("serial")
public abstract class AbstractMarketSimulation extends AbstractSimulation implements
		MarketSimulation {
	
	protected Mechanism transaction;
	protected MacroSimulation simulation;
	protected int sellersId;
	protected int buyersId;
	protected int marketId;
	
	/**
	 * @param simulationController
	 * @param population
	 */
	public AbstractMarketSimulation (){}
	
	public AbstractMarketSimulation(SimulationController simulationController,MacroSimulation simulation,
			MacroPopulation population, int sellersId, int buyersId, Mechanism transaction) {
		
	}

	/* (non-Javadoc)
	 * @see jmab.simulations.MarketSimulation#cleared()
	 */
	
	/**
	 * @return the sellersId
	 */
	public int getSellersId() {
		return sellersId;
	}

	/**
	 * @param sellersId the sellersId to set
	 */
	public void setSellersId(int sellersId) {
		this.sellersId = sellersId;
	}

	/**
	 * @return the buyersId
	 */
	public int getBuyersId() {
		return buyersId;
	}

	/**
	 * @param buyersId the buyersId to set
	 */
	public void setBuyersId(int buyersId) {
		this.buyersId = buyersId;
	}

	//the market is closed when there are either no buyers or no sellers active.
	//close mthods declared in Interface MarketMixer extending (AgentMixer) and implemented by 
	//AbstractMarketMixer.
	@Override
	public boolean closed() {
		MarketMixer marketMixer = (MarketMixer)agentMixer;
		return marketMixer.closed((MarketPopulation)population, simulation);
	}

	/* (non-Javadoc)
	 * @see net.sourceforge.jabm.Simulation#getSimulationTime()
	 */
	@Override
	public SimulationTime getSimulationTime() {
		return simulationController.getSimulationTime();
	}
	
	/**
	 * @return the transaction
	 */
	public Mechanism getTransaction() {
		return transaction;
	}

	/**
	 * @param transaction the transaction to set
	 */
	public void setTransaction(Mechanism transaction) {
		this.transaction = transaction;
	}

	/**
	 * @return the simulation
	 */
	public MacroSimulation getSimulation() {
		return simulation;
	}

	/**
	 * @param simulation the simulation to set
	 */
	
	
	public void setSimulation(MacroSimulation simulation) {
		this.simulation = simulation;
	}
	
	//if the parameter of setPopulation is already a Market Population
	public void setPopulation(MarketPopulation population) {
		this.population = population;
	}
	
	/*
	//if the parameter of setPopulation not a MarketPopulation, transform it in a 
	//MarketPopulation and then call setPopulation(MarketPopulation population)
	public void setPopulation(MacroPopulation population) {
		setPopulation(new MarketPopulation(population.getPopulation(buyersId).getAgentList(),
				population.getPopulation(sellersId).getAgentList(),population.getPrng()));
	}
	
	//if the parameter of setPopulation not a MarketPopulation, transform it in a 
		//MarketPopulation and then call setPopulation(MarketPopulation population)
	@Override
	public void setPopulation(Population population) {
		MacroPopulation macroPop= (MacroPopulation) population;
		setPopulation(new MarketPopulation(macroPop.getPopulation(buyersId).getAgentList(),
				macroPop.getPopulation(sellersId).getAgentList(),population.getPrng()));
	}
	*/
	
	/* (non-Javadoc)
	 * @see jmab.simulations.MarketSimulation#getMarketId()
	 */
	public int getMarketId() {
		return marketId;
	}

	/* (non-Javadoc)
	 * @see jmab.simulations.MarketSimulation#setMarketId(int)
	 */
	public void setMarketId(int marketId) {
		this.marketId=marketId;
	}
	
	/* (non-Javadoc)
	 * @see jmab.simulations.GoodMarketSimulation#commitTransaction(net.sourceforge.jabm.agent.Agent, net.sourceforge.jabm.agent.Agent, int)
	 */
	
	//realize exchange based on a specific transactionMechanism 
	public void commit(Agent buyer, Agent seller, int idMarket) {
		transaction.execute(buyer, seller, idMarket);
	}

	public void subscribeToEvents(EventScheduler scheduler){
		this.simulationController=(SimulationController) scheduler;
		transaction.setMarketSimulation(this);
		transaction.subscribeToEvents(scheduler);
	}
	
	public int getRound(){
		return simulation.getRound();
	}
}

/*
 * JMAB - Java Macroeconomic Agent Based Modeling Toolkit
 * Copyright (C) 2013 Alessandro Caiani and Antoine Godin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 3 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 */
package jmab.strategies;

import java.util.ArrayList;

import jmab.agents.Creditor;
import jmab.agents.Debtor;
import net.sourceforge.jabm.EventScheduler;
import net.sourceforge.jabm.agent.Agent;
import net.sourceforge.jabm.strategy.AbstractStrategy;

/**
 * @author Alessandro Caiani and Antoine Godin
 *
 */
@SuppressWarnings("serial")
public class CheapestLenderWithSwitching extends AbstractStrategy implements
		BorrowingStrategyWithSwitching {

	private Creditor previousLender;
	private SwitchingStrategy strategy;
	
	/**
	 * 
	 */
	public CheapestLenderWithSwitching() {
		super();
		this.previousLender=null;
	}

	/**
	 * @param agent
	 */
	public CheapestLenderWithSwitching(Agent agent) {
		super(agent);
		this.previousLender=null;
	}

	/**
	 * @param scheduler
	 * @param agent
	 */
	public CheapestLenderWithSwitching(EventScheduler scheduler, Agent agent) {
		super(scheduler, agent);
		this.previousLender=null;
	}

	/**
	 * @return the strategy
	 */
	public SwitchingStrategy getStrategy() {
		return strategy;
	}

	/**
	 * @param strategy the strategy to set
	 */
	public void setStrategy(SwitchingStrategy strategy) {
		this.strategy = strategy;
	}

	/**
	 * @return the previousLender
	 */
	public Creditor getPreviousLender() {
		return previousLender;
	}
	
	/* (non-Javadoc)
	 * @see jmab.strategies.BorrowingStrategyWithSwitching#setPreviousLender(jmab.agents.Creditor)
	 */
	@Override
	public void setPreviousLender(Creditor counterpart) {
		this.previousLender=counterpart;

	}

	/* (non-Javadoc)
	 * @see jmab.strategies.BorrowingStrategy#selectLender(java.util.ArrayList, double, int)
	 */
	/* (non-Javadoc)
	 * @see jmab.strategy.BorrowingStrategy#selectLender(java.util.ArrayList)
	 */
	@Override
	public Agent selectLender(ArrayList<Agent> lenders,double amount, int length) {
		double minRate=Double.POSITIVE_INFINITY;
		Creditor minLender=(Creditor) lenders.get(0);
		Debtor debtor = (Debtor) getAgent();
		for(Agent agent : lenders){
			Creditor lender=(Creditor)agent;
			double tempRate=lender.getInterestRate(debtor,amount, length);
			if(tempRate<minRate){
				minRate=tempRate;
				minLender=lender;
			}
		}
		double previousRate=previousLender.getInterestRate(debtor, amount, length);
		if(previousRate>minRate){
			if(previousRate==Double.POSITIVE_INFINITY||strategy.switches(previousRate, minRate)){
				previousLender=minLender;
			}
		}
		return previousLender;
	}

	

}

/*
 * JMAB - Java Macroeconomic Agent Based Modeling Toolkit
 * Copyright (C) 2013 Alessandro Caiani and Antoine Godin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 3 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 */
package jmab.strategies;

import java.util.HashMap;
import java.util.Iterator;

import net.sourceforge.jabm.EventScheduler;
import net.sourceforge.jabm.agent.Agent;
import net.sourceforge.jabm.strategy.AbstractStrategy;
import net.sourceforge.jabm.strategy.Strategy;

/**
 * @author Alessandro Caiani and Antoine Godin
 *
 */
@SuppressWarnings("serial")
public class MacroMultipleStrategy extends AbstractStrategy implements
		MacroStrategy {

	protected HashMap<Integer,Strategy> strategies;
	
	/**
	 * 
	 */
	public MacroMultipleStrategy() {
	}

	/**
	 * @param agent
	 */
	public MacroMultipleStrategy(Agent agent) {
		super(agent);
	}

	/**
	 * @param scheduler
	 * @param agent
	 */
	public MacroMultipleStrategy(EventScheduler scheduler, Agent agent) {
		super(scheduler, agent);
	}

	/* (non-Javadoc)
	 * @see jmab.strategies.MacroStrategy#getStrategy(int)
	 */
	@Override
	public Strategy getStrategy(int strategyID) {
		return strategies.get(strategyID);
	}

	
	@Override
	public void setAgent(Agent agent){
		Iterator<Integer> keys = strategies.keySet().iterator();
		while(keys.hasNext()){
			Integer key = (Integer) keys.next();
			Strategy strategy=(Strategy) strategies.get(key);
			strategy.setAgent(agent);
		}
	}
	
	@Override
	public void subscribeToEvents(EventScheduler scheduler){
		Iterator<Integer> keys = strategies.keySet().iterator();
		while(keys.hasNext()){
			Integer key = (Integer) keys.next();
			Strategy strategy=(Strategy) strategies.get(key);
			strategy.subscribeToEvents(scheduler);
		}
	}
	
	@Override
	public void unsubscribeFromEvents(){
		Iterator<Integer> keys = strategies.keySet().iterator();
		while(keys.hasNext()){
			Integer key = (Integer) keys.next();
			Strategy strategy=(Strategy) strategies.get(key);
			strategy.unsubscribeFromEvents();
		}
	}

	/**
	 * @return the strategies
	 */
	public HashMap<Integer, Strategy> getStrategies() {
		return strategies;
	}

	/**
	 * @param strategies the strategies to set
	 */
	public void setStrategies(HashMap<Integer,Strategy> strategies) {
		this.strategies = strategies;
	}
	
}

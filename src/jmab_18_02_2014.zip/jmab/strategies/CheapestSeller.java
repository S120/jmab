/*
 * JMAB - Java Macroeconomic Agent Based Modeling Toolkit
 * Copyright (C) 2013 Alessandro Caiani and Antoine Godin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 3 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 */
package jmab.strategies;

import java.util.ArrayList;

import jmab.agents.Buyer;
import jmab.agents.Seller;
import net.sourceforge.jabm.EventScheduler;
import net.sourceforge.jabm.agent.Agent;
import net.sourceforge.jabm.strategy.AbstractStrategy;

/**
 * @author Alessandro Caiani and Antoine Godin
 *
 */
@SuppressWarnings("serial")
public class CheapestSeller extends AbstractStrategy implements BuyingStrategy {

	/**
	 * 
	 */
	public CheapestSeller() {
	}

	/**
	 * @param agent
	 */
	public CheapestSeller(Agent agent) {
		super(agent);
	}

	/**
	 * @param scheduler
	 * @param agent
	 */
	public CheapestSeller(EventScheduler scheduler, Agent agent) {
		super(scheduler, agent);
	}

	/* (non-Javadoc)
	 * @see jmab.strategy.BuyingStrategy#selectSeller(java.util.ArrayList)
	 */
	@Override
	public Agent selectSeller(ArrayList<Agent> sellers,double demand, boolean real) {
		double minPrice=Double.POSITIVE_INFINITY;
		Seller minSeller=(Seller) sellers.get(0);
		Buyer buyer = (Buyer) getAgent();
		for(Agent agent : sellers){
			Seller seller=(Seller)agent;
			double tempPrice=seller.getPrice(buyer, demand,real);
			if(tempPrice<minPrice){
				minPrice=tempPrice;
				minSeller=seller;
			}
		}
		return minSeller;
	}

}

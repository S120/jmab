/*
 * JMAB - Java Macroeconomic Agent Based Modeling Toolkit
 * Copyright (C) 2013 Alessandro Caiani and Antoine Godin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 3 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 */
package jmab.mechanisms;

import jmab.agents.Creditor;
import jmab.agents.Debtor;
import jmab.simulations.MarketSimulation;
import net.sourceforge.jabm.EventScheduler;
import net.sourceforge.jabm.agent.Agent;

/**
 * @author Alessandro Caiani and Antoine Godin
 *
 */
//according to this mechanism borrowers always obtain the required amount of credit
public class UnconstrainedCreditMechanism extends AbstractCreditMechanism implements Mechanism {

	public UnconstrainedCreditMechanism(){}
	
	/**
	 * @param scheduler
	 * @param market
	 */
	public UnconstrainedCreditMechanism(EventScheduler scheduler, MarketSimulation market, boolean delayed,
			int irSetting, int amortization) {
		super(scheduler, market,delayed, irSetting, amortization);
	}

	private void execute(Debtor debtor, Creditor creditor, int idMarket) {
		double amount=debtor.getLoanRequirement();
		int length=debtor.getLoanLength();
		double interestRate=creditor.getInterestRate(debtor, amount, length);
		debtor.borrow(idMarket, amount, interestRate);
		debtor.setActive(false, idMarket);
		creditor.lend(idMarket, amount, interestRate);
		super.addCreditRelation(debtor, creditor, amount, interestRate, length, irSetting, amortization);
	}	
	
	//store orders to be committed with delay and in the meanwhile set the borrower inactive
	private void storeOrder(Debtor debtor, Creditor creditor, int idMarket){
		addTransaction(debtor, creditor, idMarket);
		debtor.setActive(false, idMarket);
	}
	
	/* (non-Javadoc)
	 * @see jmab.mechanisms.Mechanism#execute(net.sourceforge.jabm.agent.Agent, net.sourceforge.jabm.agent.Agent, int)
	 */
	
	@Override
	public void execute(Agent buyer, Agent seller, int idMarket) {
		if(delayed)
			storeOrder((Debtor) buyer, (Creditor) seller, idMarket);
		else
			execute((Debtor) buyer, (Creditor) seller, idMarket);
	}

	/* (non-Javadoc)
	 * @see jmab.mechanisms.AbstractMechanism#commit(net.sourceforge.jabm.agent.Agent, net.sourceforge.jabm.agent.Agent, int)
	 */
	@Override
	protected void commit(Agent buyer, Agent seller, int idMarket) {
		if(delayed)
			execute((Debtor) buyer, (Creditor) seller, idMarket);
	}

}

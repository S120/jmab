/*
 * JMAB - Java Macroeconomic Agent Based Modeling Toolkit
 * Copyright (C) 2013 Alessandro Caiani and Antoine Godin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 3 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 */
package jmab.mechanisms;

import java.util.ArrayDeque;

import jmab.events.MarketInteractionsFinishedEvent;
import jmab.simulations.MarketSimulation;
import net.sourceforge.jabm.EventScheduler;
import net.sourceforge.jabm.agent.Agent;
import net.sourceforge.jabm.event.SimEvent;
import net.sourceforge.jabm.event.SimulationFinishedEvent;

/**
 * @author Alessandro Caiani and Antoine Godin
 *
 */
public abstract class AbstractMechanism implements Mechanism {

	protected EventScheduler scheduler;

	protected MarketSimulation market;
	
	protected ArrayDeque<Object[]> transactions;
	
	protected boolean delayed;
	
	private final int ID_BUYER=0;
	private final int ID_SELLER=1;
	private final int ID_TRANSACTION=2;
	
	/**
	 * @param scheduler
	 * @param market
	 */
	public AbstractMechanism (){
		transactions= new ArrayDeque<Object[]>();
	}
	
	public AbstractMechanism(EventScheduler scheduler, MarketSimulation market,boolean delayed) {
		this.delayed=delayed;
		transactions= new ArrayDeque<Object[]>();
	}

	/**
	 * @param market the market to set
	 */
	public void setMarket(MarketSimulation market) {
		this.market = market;
	}

	/**
	 * @return the transactions
	 */
	public ArrayDeque<Object[]> getTransactions() {
		return transactions;
	}

	/**
	 * @param transactions the transactions to set
	 */
	public void setTransactions(ArrayDeque<Object[]> transactions) {
		this.transactions = transactions;
	}

	/**
	 * @return the delayed
	 */
	public boolean isDelayed() {
		return delayed;
	}

	/**
	 * @param delayed the delayed to set
	 */
	public void setDelayed(boolean delayed) {
		this.delayed = delayed;
	}
	
	/* (non-Javadoc)
	 * @see jmab.mechanisms.Mechanism#setMarketSimulation(jmab.simulations.MarketSimulation)
	 */
	@Override
	public void setMarketSimulation(MarketSimulation market) {
		this.market=market;

	}

	/* (non-Javadoc)
	 * @see jmab.mechanisms.Mechanism#getMarketSimulation()
	 */
	@Override
	public MarketSimulation getMarketSimulation() {
		return market;
	}

	/* (non-Javadoc)
	 * @see jmab.mechanisms.Mechanism#subscribeToEvents(net.sourceforge.jabm.EventScheduler)
	 */
	public void subscribeToEvents(EventScheduler scheduler) {
		this.scheduler = scheduler;
		subscribeToEvents();
	}
	
	public void subscribeToEvents() {
		scheduler.addListener(SimulationFinishedEvent.class, this);
		scheduler.addListener(MarketInteractionsFinishedEvent.class, this);
	}

	/* (non-Javadoc)
	 * @see jmab.mechanisms.Mechanism#unsubscribeFromEvents()
	 */
	public void unsubscribeFromEvents() {
		scheduler.removeListener(this);
	}

	/**
	 * @return the scheduler
	 */
	public EventScheduler getScheduler() {
		return scheduler;
	}

	/**
	 * @param scheduler the scheduler to set
	 */
	public void setScheduler(EventScheduler scheduler) {
		this.scheduler = scheduler;
		subscribeToEvents();
	}
	
	/* (non-Javadoc)
	 * @see net.sourceforge.jabm.event.EventListener#eventOccurred(net.sourceforge.jabm.event.SimEvent)
	 */
	@Override
	public void eventOccurred(SimEvent event) {
		if(event instanceof MarketInteractionsFinishedEvent){
			commitAll();
		}else if(event instanceof SimulationFinishedEvent){
			onSimulationFinished();
		}
	}
	
	public void onSimulationFinished() {
		unsubscribeFromEvents();
	}
	
	protected void addTransaction(Agent buyer, Agent seller, int idTransaction){
		Object[] transaction = new Object[3];
		transaction[ID_BUYER]=buyer;
		transaction[ID_SELLER]=seller;
		transaction[ID_TRANSACTION]=idTransaction;
		transactions.addFirst(transaction);
	}
	
	protected void commitAll(){
		for(Object[] transaction:transactions){
			Agent buyer = (Agent) transaction[ID_BUYER];
			Agent seller = (Agent) transaction[ID_SELLER];
			int idTransaction = (Integer) transaction[ID_TRANSACTION];
			commit(buyer,seller,idTransaction);
			transactions.remove(transaction);
		}
	}

	/**
	 * @param buyer
	 * @param seller
	 * @param idTransaction
	 */
	protected abstract void commit(Agent buyer, Agent seller, int idTransaction);

}

/*
 * JMAB - Java Macroeconomic Agent Based Modeling Toolkit
 * Copyright (C) 2013 Alessandro Caiani and Antoine Godin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 3 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 */
package jmab.mechanisms;

import jmab.agents.Creditor;
import jmab.agents.Debtor;
import jmab.simulations.MarketSimulation;
import net.sourceforge.jabm.EventScheduler;
import net.sourceforge.jabm.agent.Agent;

/**
 * @author Alessandro Caiani and Antoine Godin
 *
 */
//with this mechanism borrowers' demand for credit can be constrained by lenders' supply
public class ConstrainedCreditMechanism extends AbstractCreditMechanism implements
		Mechanism {
	
	/**
	 * @param scheduler
	 * @param market
	 */
	public ConstrainedCreditMechanism(){}
	
	public ConstrainedCreditMechanism(EventScheduler scheduler,
			MarketSimulation market, boolean delayed, int irSetting, int amortization) {
		super(scheduler, market,delayed, irSetting, amortization);
	}

	private void execute(Debtor debtor, Creditor creditor, int idMarket) {
		double required=debtor.getLoanRequirement();
		int length=debtor.getLoanLength();
		double offered=creditor.getLoanSupply(debtor,required);
		double amount=Math.min(required, offered);
		double interestRate=creditor.getInterestRate(debtor, amount,length);
		debtor.borrow(idMarket, amount, interestRate);
		creditor.lend(idMarket, amount, interestRate);
		if(Math.min(required, offered)==required){
			debtor.setActive(false, idMarket);
		}
		else{
			creditor.setActive(false, idMarket);
		}
		super.addCreditRelation(debtor, creditor, amount, interestRate, length, irSetting, amortization);
	}
	
	//store orders to be committed with delay and in the meanwhile set the borrower inactive
	private void storeOrder(Debtor debtor, Creditor creditor, int idMarket){
		addTransaction(debtor, creditor, idMarket);
		double required=debtor.getLoanRequirement();
		double offered=creditor.getLoanSupply(debtor,required);
		if(Math.min(required, offered)==required){
			debtor.setActive(false, idMarket);
			}
		else{
			creditor.setActive(false, idMarket);
			}
	}
	/* (non-Javadoc)
	 * @see jmab.mechanisms.Mechanism#execute(net.sourceforge.jabm.agent.Agent, net.sourceforge.jabm.agent.Agent, int)
	 */
	@Override
	public void execute(Agent buyer, Agent seller, int idMarket) {
		if (delayed)
			storeOrder((Debtor) buyer, (Creditor) seller, idMarket);
		else
			execute((Debtor) buyer, (Creditor) seller, idMarket);

	}

	/* (non-Javadoc)
	 * @see jmab.mechanisms.AbstractMechanism#commit(net.sourceforge.jabm.agent.Agent, net.sourceforge.jabm.agent.Agent, int)
	 */
	@Override
	protected void commit(Agent buyer, Agent seller, int idMarket) {
		execute((Debtor) buyer, (Creditor) seller, idMarket);
	}

}

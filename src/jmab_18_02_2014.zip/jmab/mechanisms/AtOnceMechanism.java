/*
 * JMAB - Java Macroeconomic Agent Based Modeling Toolkit
 * Copyright (C) 2013 Alessandro Caiani and Antoine Godin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 3 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 */
package jmab.mechanisms;

import jmab.agents.Buyer;
import jmab.agents.Seller;
import jmab.events.TransactionOccuredEvent;
import jmab.simulations.MarketSimulation;
import net.sourceforge.jabm.EventScheduler;
import net.sourceforge.jabm.agent.Agent;

/**
 * @author Alessandro Caiani and Antoine Godin
 *
 */

//according to this mechanism buyers buy all their nominal demand at once
public class AtOnceMechanism extends AbstractMechanism implements
		Mechanism {

	private boolean real;

	/**
	 * @param scheduler
	 * @param market
	 */
	
	public AtOnceMechanism (){}
	
	public AtOnceMechanism(EventScheduler scheduler,
			MarketSimulation market, boolean delayed, boolean real) {
		super(scheduler, market, delayed);
		this.real=real;
	}

	/**
	 * @return the real
	 */
	public boolean isReal() {
		return real;
	}

	/**
	 * @param real the real to set
	 */
	public void setReal(boolean real) {
		this.real = real;
	}
	
	/* (non-Javadoc)
	 * @see jmab.mechanisms.TransactionMechanism#executeTransaction(jmab.agents.Buyer, jmab.agents.Seller, int)
	 */
	private void execute(Buyer buyer, Seller seller, int idGood) {
		double demand;
		if(real)
			demand=buyer.getRealDemand();
		else
			demand=buyer.getNominalDemand();
		double output=seller.getOutput();
		double price=seller.getPrice(buyer, demand, real);
		double quantity;
		if(real)
			quantity=Math.min(demand,output);
		else
			quantity=Math.min(demand/price,output);
		buyer.buy(idGood, quantity, price);
		seller.sell(idGood, quantity, price);
		if (quantity==demand){
			buyer.setActive(false, idGood);
		}
		else {
			seller.setActive(false, idGood);
		}
		this.scheduler.fireEvent(new TransactionOccuredEvent(quantity, price, this.market.getMarketId(),this.market.getRound()));
	}
	
	//store orders to be committed with delay and in the meanwhile set the buyer inactive
	private void storeOrder(Buyer buyer, Seller seller, int idMarket){
		addTransaction(buyer, seller, idMarket);
		double demand;
		if(real)
			demand=buyer.getRealDemand();
		else
			demand=buyer.getNominalDemand();
		double output=seller.getOutput();
		double price=seller.getPrice(buyer, demand, real);
		double quantity;
		if(real)
			quantity=Math.min(demand,output);
		else
			quantity=Math.min(demand/price,output);
		if (quantity==demand){
			buyer.setActive(false, idMarket);
		}
		else {
			seller.setActive(false, idMarket);
		}
	}

	/* (non-Javadoc)
	 * @see jmab.mechanisms.TransactionMechanism#execute(net.sourceforge.jabm.agent.Agent, net.sourceforge.jabm.agent.Agent, int)
	 */
	@Override
	public void execute(Agent buyer, Agent seller, int idMarket) {
		if(delayed)
			storeOrder((Buyer) buyer, (Seller) seller, idMarket);
		else
			execute((Buyer) buyer, (Seller) seller, idMarket);
	}

	/* (non-Javadoc)
	 * @see jmab.mechanisms.AbstractMechanism#commit(net.sourceforge.jabm.agent.Agent, net.sourceforge.jabm.agent.Agent, int)
	 */
	@Override
	protected void commit(Agent buyer, Agent seller, int idMarket) {
		execute((Buyer) buyer, (Seller) seller, idMarket);
	}

}

/*
 * JMAB - Java Macroeconomic Agent Based Modeling Toolkit
 * Copyright (C) 2013 Alessandro Caiani and Antoine Godin
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 3 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 */
package jmab.mechanisms;

import java.util.ArrayList;
import java.util.List;

import jmab.agents.Creditor;
import jmab.agents.Debtor;
import jmab.events.BadDebtEvent;
import jmab.events.MarketInteractionsFinishedEvent;
import jmab.events.MarketInteractionsStartingEvent;
import jmab.simulations.MarketSimulation;
import net.sourceforge.jabm.EventScheduler;
import net.sourceforge.jabm.event.SimEvent;

/**
 * @author Alessandro Caiani and Antoine Godin
 *
 */
public abstract class AbstractCreditMechanism extends AbstractMechanism implements
		Mechanism {

	protected boolean beginPayment;
	protected List<CreditRelation> relations;
	protected int irSetting;
	protected int amortization;
	
	/**
	 * @param scheduler
	 * @param market
	 * @param delayed
	 */
	public AbstractCreditMechanism(){
		super();
		relations=new ArrayList<CreditRelation>();
	}

	public AbstractCreditMechanism(EventScheduler scheduler,
			MarketSimulation market, boolean delayed, int irSetting, int amortization) {
		super(scheduler, market, delayed);
		relations=new ArrayList<CreditRelation>();
		this.irSetting=irSetting;
		this.amortization=amortization;
	}

	/**
	 * @return the beginPayment
	 */
	public boolean isBeginPayment() {
		return beginPayment;
	}

	/**
	 * @param beginPayment the beginPayment to set
	 */
	public void setBeginPayment(boolean beginPayment) {
		this.beginPayment = beginPayment;
	}

	/**
	 * @return the relations
	 */
	public List<CreditRelation> getRelations() {
		return relations;
	}

	/**
	 * @param relations the relations to set
	 */
	public void setRelations(List<CreditRelation> relations) {
		this.relations = relations;
	}

	/**
	 * @return the irSetting
	 */
	public int getIrSetting() {
		return irSetting;
	}

	/**
	 * @param irSetting the irSetting to set
	 */
	public void setIrSetting(int irSetting) {
		this.irSetting = irSetting;
	}

	/**
	 * @return the amortization
	 */
	public int getAmortization() {
		return amortization;
	}

	/**
	 * @param amortization the amortization to set
	 */
	public void setAmortization(int amortization) {
		this.amortization = amortization;
	}

	public void addCreditRelation(Debtor debtor, Creditor creditor, double amount, double interestRate, 
			int length, int irSetting, int amortization){
		relations.add(new CreditRelation(debtor, creditor, interestRate, amount, 
				length, irSetting, amortization));
	}
	
	@Override
	public void eventOccurred(SimEvent event) {
		super.eventOccurred(event);
		if(event instanceof MarketInteractionsStartingEvent){
			updatePeriod();
			if(beginPayment)
				creditPayments();
			updateIRate();
		}else if(event instanceof MarketInteractionsFinishedEvent){
			if(!beginPayment)
				creditPayments();
			updateRelations();
		}
	}

	/**
	 * 
	 */
	private void updateRelations() {
		List<CreditRelation> remainingRelations = new ArrayList<CreditRelation>();
		for(CreditRelation relation:relations){
			if(relation.getAmount()!=0){
				remainingRelations.add(relation);
			}
		}
		relations=remainingRelations;
	}

	/**
	 * 
	 */
	private void updateIRate() {
		for(CreditRelation relation:relations){
			if(relation.getIrSetting()==CreditRelation.FLOATING_IR){
				Debtor debtor=relation.getDebtor();
				Creditor creditor=relation.getCreditor();
				double amount=relation.getAmount();
				int length = relation.getLength();
				int period = relation.getPeriod();
				double iRate=creditor.getInterestRate(debtor, amount, length-period);
				relation.setInterestRate(iRate);
			}
		}
	}

	/**
	 * 
	 */
	private void updatePeriod() {
		for(CreditRelation relation:relations){
			relation.update();
		}
	}

	/**
	 * 
	 */
	private void creditPayments() {
		for(CreditRelation relation:relations){
			Debtor debtor=relation.getDebtor();
			Creditor creditor=relation.getCreditor();
			double iRate=relation.getInterestRate();
			double amount=relation.getAmount();
			int length = relation.getLength();
			double interests=iRate*amount;
			double principal=0.0;
			switch(relation.getAmortization()){
			case CreditRelation.FIXED_AMOUNT:
				double amortization = amount*(iRate*Math.pow(1+iRate, length))/(Math.pow(1+iRate, length)-1);
				principal=amortization-interests;
				break;
			case CreditRelation.FIXED_CAPITAL:
				principal=amount/length;
				break;
			case CreditRelation.ONLY_INTERESTS:
				if(length==relation.getPeriod())
					principal=amount;
				break;
			}
			double paid=debtor.payInterest(interests);
			if(paid!=interests){
				this.scheduler.fireEvent(new BadDebtEvent((interests-paid+amount), this.market.getMarketId(),this.market.getRound()));
				creditor.receiveInterest(paid);
				relation.setAmount(0);
			}else{
				creditor.receiveInterest(paid);
				paid=debtor.repayPrincipal(principal);
				if(paid!=principal){
					this.scheduler.fireEvent(new BadDebtEvent((amount-paid), this.market.getMarketId(),this.market.getRound()));
					creditor.receivePrincipalRepayment(paid);
					relation.setAmount(0);
				}else{
					creditor.receivePrincipalRepayment(paid);
					relation.setAmount(amount-paid);
				}
			}
		}	
	}
	
	@Override
	public void subscribeToEvents() {
		super.subscribeToEvents();
		scheduler.addListener(MarketInteractionsStartingEvent.class, this);
	}
}
